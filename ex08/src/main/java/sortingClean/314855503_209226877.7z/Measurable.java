package sortingClean;

public @interface Measurable {
}
